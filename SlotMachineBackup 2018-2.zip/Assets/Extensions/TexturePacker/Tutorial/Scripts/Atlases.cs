////////////////////////////////////////////////////////////////////////////////
//  
// @module Texture Packer Plugin for Unity3D 
// @author Osipov Stanislav lacost.st@gmail.com
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Atlases : MonoBehaviour {

	public const string EXAMPLE    = "TutorialAtlas";
	public const string EXAMPLE2    = "Example";
	
}
