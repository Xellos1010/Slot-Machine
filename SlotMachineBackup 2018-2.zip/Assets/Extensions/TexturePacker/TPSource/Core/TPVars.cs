using UnityEngine;
using System.Collections;

public class TPVars  {
	public static bool isFreeVersion = false;
	
}

