using UnityEngine;
using System.Collections;

public interface TPFrameHolder  {

	void addFrame(TPFameInfo frame);
}

