using UnityEngine;
using System.Collections;

public class TPMeta {
	public string image;
	public string format;
	
	public Size2D atlasSize;
	public Size2D imageSize;
	
	public float scale;
	
}

