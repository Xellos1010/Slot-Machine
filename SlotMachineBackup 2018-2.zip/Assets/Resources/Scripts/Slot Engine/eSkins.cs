﻿using UnityEngine;
using System.Collections;

public enum eSkins
{
    None,
    Aegean_Sunset
}
