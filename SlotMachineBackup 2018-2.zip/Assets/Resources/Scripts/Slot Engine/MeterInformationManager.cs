﻿using UnityEngine;
using System.Collections;

public class MeterInformationManager : GenericMeter 
{
    public PanelInformation Information;
}
