﻿using UnityEngine;
using System.Collections;

public enum eMeters
{
    None = -1,
    Bet = 0,
    Win = 1,
    Credit = 2,
    FreeGameRemaining = 3,
    Last
}
