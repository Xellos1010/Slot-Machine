﻿public enum eEvaluationDirection
{
    None = -1,
    Left = 0,
    Right = 1,
    Both = 2
}